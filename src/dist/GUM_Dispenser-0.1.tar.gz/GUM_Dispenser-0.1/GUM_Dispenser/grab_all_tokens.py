# Requires dev_dir path, module name, current_data_dict

from tokenize import tokenize

import os

import token

from io import BytesIO

import pyclbr

from pprint import pprint

from pathlib import Path

import re

current_package = 'gratefullyDEAD'

current_module = 'Windows_Service_Context'

current_data_dict = {'packages' : {'gratefullyDEAD' : {'modules' : {}}}}

DEAD_path = Path('C:/Users/JOFIKE/Documents/Git Repositories/gratefullydead/src/gratefullyDEAD')

module_path = DEAD_path.joinpath(current_module + '.py')

#print(DEAD_path)

DEAD_classes_and_funcs = pyclbr.readmodule_ex(current_module, [str(DEAD_path)])

pprint(DEAD_classes_and_funcs)


# TO DO: Check result here to make sure module exists

# Initialize data for current module
current_data_dict['packages'][current_package]['modules'][current_module] = {}


module_data = current_data_dict['packages'][current_package]['modules'][current_module]

module_data['dependencies'] = []
module_data['declarations'] = []

# pprint(current_data_dict)


# Grab file text

setup_size = os.stat(str(module_path)).st_size

with open(str(module_path), 'r') as tokenized_setup:

    text = tokenized_setup.read(setup_size)

# Tokenize is a generator, so we must iterate line by line
tokens = tokenize(BytesIO(text.encode('utf-8')).readline)

split_import_statement = re.compile(r'''(\s|[.,]|from|import)+''')

# Store scope of current token
scope_tree = {current_module : {}}

current_scope_level = scope_tree[current_module]

#current_scope_name = current_module

nesting_level = 0

parent_scope = current_module

parent_dict = {current_module : {'dict': scope_tree[current_module], 'parent' : 'None'}}

for token_type, token_str, start, end, line_text in tokens:

    print(str(start) + ',' + str(end) + ':\t' + token.tok_name[token_type] + '\t' + ' (' + line_text.strip() + ')')