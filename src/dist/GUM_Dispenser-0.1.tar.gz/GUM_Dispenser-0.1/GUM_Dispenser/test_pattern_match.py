
import re

from pathlib import Path


#init_path = Path('C:/Users/JOFIKE/Documents/Git Repositories/gum_dispenser/src/test/dummy/__init__.py')

pattern = re.compile(r"""(\[[^\s|]+)|([\w:'",]+[\])]*\s*->)|([\w:'",]+[\])]*)""", re.MULTILINE)

test_string = "[GUM_Describe_Source|[def describe_project(distro_defs: dict, dev_directory: 'Path') -> dict]|[def describe_package(name: str, dev_directory: 'Path', uml_data: dict) -> dict]|[def ensure_modules_exist(found_modules: list, package_path: 'Path') -> None]|[def check_init_file(name : str, init_path : 'Path') -> list]|[def describe_module(current_package : str, current_module : str, package_path : 'Path', current_data_dict : dict)]]"

test = [match.span() for match in re.finditer(pattern, test_string)
        if match.group() != '']


characters_read_in_current_line = 0
new_lines_added = 0

for match in re.finditer(pattern, test_string):

    if match.group() != '':

        current_match_bounds = match.span()

        if characters_read_in_current_line > 60:

            test_string = test_string[:current_match_bounds[1] + new_lines_added] + '\n' + \
                                test_string[current_match_bounds[1] + new_lines_added:]

            characters_read_in_current_line = 0

            new_lines_added += 1


        else:

            characters_read_in_current_line += (current_match_bounds[1] - current_match_bounds[0])

print(test_string)


#with open(str(init_path), 'r') as init_file:

    #init_contents = init_file.read()

    # Grab the capturing group



#    init_results = [current_match.group(1).strip() for current_match in pattern.finditer(init_contents)
#                    if not current_match.group(1) is None and
#                    not (current_match.group(1).isspace() or current_match.group(1) == '')]


#print(init_results)