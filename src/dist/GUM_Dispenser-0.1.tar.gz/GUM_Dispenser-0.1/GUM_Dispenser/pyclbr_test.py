
import pyclbr

from pprint import pprint

from pathlib import Path


DEAD_path = str(Path('C:/Users/JOFIKE/Documents/Git Repositories/gratefullydead/src/gratefullyDEAD'))

print(DEAD_path)

for name, object_data in pyclbr.readmodule_ex('DEAD', [DEAD_path]).items():

    print(name + ': ' + object_data.module + '---' + object_data.file + ':' + str(object_data.lineno))

    #if type(object_data) == pyclbr.Class:

