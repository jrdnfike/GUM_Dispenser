
from GUM_Dispenser import initialize_log

from GUM_Describe_Source import describe_module

from pathlib import Path

initialize_log()

pkg = 'GUM_Dispenser'

module_name = 'tokenize_test'

data = {'packages' : {'GUM_Dispenser' : {'modules' : {}}}}

DEAD_path = Path('C:/Users/JOFIKE/Documents/Git Repositories/gum_dispenser/src/GUM_Dispenser')

describe_module(pkg, module_name, DEAD_path, data)