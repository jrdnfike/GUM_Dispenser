
from tokenize import tokenize

import os

import token

from io import BytesIO

from pathlib import Path

import re

from pprint import pprint


# Requires dev_dir path, module name, current_data_dict

def describe_module(current_package : str, current_module : str, package_path : 'Path', current_data_dict : dict):

    module_path = package_path.joinpath(current_module + '.py')


    # TO DO: Check result here to make sure module exists

    # Initialize data for current module
    current_data_dict['packages'][current_package]['modules'][current_module] = {}


    module_data = current_data_dict['packages'][current_package]['modules'][current_module]

    module_data['dependencies'] = []
    module_data['declarations'] = []

    # pprint(current_data_dict)


    # Grab file text

    setup_size = os.stat(str(module_path)).st_size

    with open(str(module_path), 'r') as tokenized_setup:

        text = tokenized_setup.read(setup_size)

    # Tokenize is a generator, so we must iterate line by line
    tokens = tokenize(BytesIO(text.encode('utf-8')).readline)

    split_import_statement = re.compile(r'''(\s|[.,]|from|import)+''')

    # Store scope of current token
    scope_tree = {current_module : {}}

    current_scope_level = scope_tree[current_module]

    current_scope_name = current_module

    nesting_level = 0

    parent_scope = current_module

    parent_dict = {current_module : {'dict': scope_tree, 'parent' : current_module}}

    for token_type, token_str, start, end, line_text in tokens:

        #  print(str(start) + ',' + str(end) + ':\t' + token.tok_name[token_type] + '\t' + ' (' + lineno.strip() + ')')

        # Catch the declaration lines for functions and classes

        # Import statements should not contain string literals
        # Possible to have lines in code printing 'import ......'

        if 'import' in line_text.lower():

            #print(line_text)

            if "'" not in line_text and '"' not in line_text:

                #if DEAD_classes_and_funcs[token_str].module != current_module:

                # Remove punctuation, whitespace, 'from' and 'import'

                import_keywords = [import_name for import_name in split_import_statement.split(line_text.strip())
                                   if not import_name.isspace() and import_name != '']

                # External dependency
                # We want to store the package dependency

                if current_package.lower() not in line_text.lower():

                    dependency = import_keywords[0]

                # The dependency is defined in our current source package

                else:

                    #print(import_keywords)

                    dependency = import_keywords[1]

                if dependency not in module_data['dependencies']:

                    module_data['dependencies'].append(dependency)



        if line_text.strip()[:3] == 'def' or line_text.strip()[:5] == 'class':

            if token.tok_name[token_type] == 'NAME' and token_str != 'def' and token_str != 'class':

                signature = line_text.strip().rstrip(':')

                if signature not in module_data['declarations']:

                    print('Caught declaration for', token_str)

                    module_data['declarations'].append(signature)

                    if signature not in current_scope_level:

                        parent_dict[signature] = {'parent' : parent_scope,
                                                  'dict' : current_scope_level}

                        current_scope_level[signature] = {}


                    parent_scope = signature

                    current_scope_level = current_scope_level[parent_scope]

            elif token.tok_name[token_type] == 'DEDENT':

                #print(line_text)

                #print(scope_tree)

                # Ignore if we have multiple dedents consecutively for same module level function

                if signature != current_scope_name:

                    print('Exiting scope: ' + parent_scope)

                    parent_scope = parent_dict[parent_scope]['parent']

                    current_scope_level = parent_dict[parent_scope]['dict']

                    nesting_level -= 1

                    print('Decremented nesting level: ', nesting_level)

                else:

                    nesting_level -= 1

                    print('Decremented nesting level: ', nesting_level)


                # Need to track scope level changes to store this
                #module_data['declarations'][token_str]['parent'] = token_scope

                #token_scope = token_scope

        elif token.tok_name[token_type] == 'DEDENT':

            nesting_level -= 1

            current_scope_name = line_text.strip().rstrip(':')

            print('Decremented nesting level: ', nesting_level, 'at line', line_text)

        if token.tok_name[token_type] == 'INDENT':

            nesting_level += 1

            current_scope_name = line_text.strip().rstrip(':')

            print('Incremented nesting level: ', nesting_level, 'at line', line_text)

    module_data['declarations'] = scope_tree

    return current_data_dict


def print_tokens(current_module : str, package_path : 'Path'):

    module_path = package_path.joinpath(current_module + '.py')


    # TO DO: Check result here to make sure module exists

    # Initialize data for current module
    #current_data_dict['packages'][current_package]['modules'][current_module] = {}


    #module_data = current_data_dict['packages'][current_package]['modules'][current_module]

    #module_data['dependencies'] = []
    #module_data['declarations'] = []

    # pprint(current_data_dict)


    # Grab file text

    setup_size = os.stat(str(module_path)).st_size

    with open(str(module_path), 'r') as tokenized_setup:

        text = tokenized_setup.read(setup_size)

    # Tokenize is a generator, so we must iterate line by line
    tokens = tokenize(BytesIO(text.encode('utf-8')).readline)

    for token_type, token_str, start, end, line_text in tokens:

        print(str(start) + ',' + str(end) + ':\t' + token.tok_name[token_type] + '\t' + line_text.strip().rstrip(','))


#print(current_data_dict)

pkg = 'test'

module_name = 'setup'

data = {'packages' : {'test' : {'modules' : {}}}}

DEAD_path = Path('C:/Users/JOFIKE/Documents/Git Repositories/awshuccs/src')

print_tokens(module_name, DEAD_path)
